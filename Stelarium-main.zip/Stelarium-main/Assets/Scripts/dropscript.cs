using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class dropscript : MonoBehaviour
{
    public bool right; // coché = right ; decoché = wrong / indique si la dropzone fait partie des bonnes drops ou non
    public bool filed;
    // Start is called before the first frame update
    void Start()
    {
        filed = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
